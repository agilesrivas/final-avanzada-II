export class User {
    email: string | null;
    password: string | null;

    constructor() {
        this.email = "";
        this.password = "";
    }
}
